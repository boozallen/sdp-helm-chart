(window.webswingRequirejs ? window.webswingRequirejs : window).define({
    root: {
        "en-US": "English",
        "de-DE": "German"
    }
})